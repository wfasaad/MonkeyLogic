%mlflush


mlvideo('flush');
daqreset;
sound clear;
clear all;
fclose all;
close all;
